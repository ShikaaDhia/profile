import 'package:flutter/material.dart';
import 'package:profile/const.dart';
import 'package:profile/ui/profile/profile_screen.dart';


void main() {
  runApp(const Snaft());
}

class Snaft extends StatelessWidget {
  const Snaft({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Snaft',
      theme: ThemeData(
        scaffoldBackgroundColor: Colors.white,
        fontFamily: 'Signika',
        visualDensity: VisualDensity.adaptivePlatformDensity,
        textTheme: const TextTheme(
          bodyMedium: TextStyle(color: textColor),
          bodySmall: TextStyle(color: textColorSmall)
        ),
      ),
      home: const ProfileScreen(),
    );
  }
}

