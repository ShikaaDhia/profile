import 'package:flutter/material.dart';

// Coloring
const primaryColor = Color(0xFF6BC75B);
const secondaryColor = Color(0xFFFF8473);
const secondaryColorThin = Color(0xFFFFC0B8);

const textColor = Color(0xFF333335);
const textColorSmall = Color(0xFF8C8C8C);