import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: const [
          CircleAvatar(
            backgroundImage: AssetImage('assets/images/user-cntk.png'),
          )
        ],
      ),
    );
  }
}